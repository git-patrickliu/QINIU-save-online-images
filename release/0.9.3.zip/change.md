changelog
====

### 0.4
1. deleteCookie方法，在url后面加上/,说明是path

### 0.5
1. override the new tab page

### 0.6
1. 去掉the new tab page

### 0.7
1. 优化代码结构

### 0.8
1. 换上圣诞帽

### 0.9
1. user storage.sync to sync data

### 0.9.1
1. sync local data

### 0.9.2
1.因为bug, revert to 0.8

### 0.9.3
1. manifest.json 里面出现./ 会导致crash refer to https://code.google.com/p/chromium/issues/detail?id=437675