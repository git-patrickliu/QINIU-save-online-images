changelog
====

0.0.1 第一个release.

--------

0.0.2
1. add after install, open the options.html by default.
--------
0.0.3
1. fix bug. get base64 method slice(22) is wrong.

--------
0.0.4
1. manifest.json, no all_frames.

