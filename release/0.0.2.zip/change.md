changelog
====

0.0.1 第一个release.

--------

0.0.2
1. add after install, open the options.html by default.

