chrome.devtools.panels.create(
    'webInterfaceLog',
    null, // No icon path
    'html/webInterfaceLog.html',
    null // no callback needed
);

