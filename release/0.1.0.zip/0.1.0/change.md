changelog
====

0.0.1 第一个release.

--------

0.0.2
1. add after install, open the options.html by default.
--------
0.0.3
1. fix bug. get base64 method slice(22) is wrong.

--------
0.0.4
1. manifest.json, no all_frames.

--------
0.0.5
1. fix tabs.sendMessage && runtime.sendMessage bugs or wrong useage.

--------
0.0.6
1. 添加一个新feature, 就是在popup中,支持ctrl[cmd]+v直接上传图片(一般用于截图的保存).
---------
0.0.7
1. 增加多个目录上传
---------
0.0.8
1. 无后缀的url图片,默认后缀为jpeg

---------
0.1.0
1. 使用vue重构代码
2. 实现了多bucket, 多文件夹功能
3. 自定义文件名
